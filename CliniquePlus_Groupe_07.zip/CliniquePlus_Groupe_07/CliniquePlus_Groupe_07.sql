-- Section 1 : Cr�ation de la base et du sch�ma

CREATE DATABASE CliniquePlus_Groupe_07 ;
GO

USE CliniquePlus_Groupe_07;
GO

CREATE SCHEMA clinique;
GO

--- Section 2 : Cr�ation des tables

CREATE TABLE clinique.Specialites (
    SpecialiteID INT IDENTITY(1,1) PRIMARY KEY,
    Libelle NVARCHAR(100) NOT NULL UNIQUE,
    TarifBase DECIMAL(10,2) NOT NULL CHECK (TarifBase > 0)
);

----

CREATE TABLE clinique.Medecins (
    MedecinID INT IDENTITY(1,1) PRIMARY KEY,
    Matricule VARCHAR(10) UNIQUE NOT NULL,
    Nom NVARCHAR(50) NOT NULL,
    Prenom NVARCHAR(50) NOT NULL,
    Email VARCHAR(100) UNIQUE,
    Telephone VARCHAR(20),
    DateEmbauche DATE NOT NULL,
    Salaire DECIMAL(10,2) CHECK (Salaire > 0),
    SpecialiteID INT NOT NULL,

    FOREIGN KEY (SpecialiteID)
    REFERENCES clinique.Specialites(SpecialiteID)
);

----

CREATE TABLE clinique.Patients (
    PatientID INT IDENTITY(1,1) PRIMARY KEY,
    NumeroDossier VARCHAR(20) UNIQUE NOT NULL,
    Nom NVARCHAR(50) NOT NULL,
    Prenom NVARCHAR(50) NOT NULL,
    Sexe CHAR(1) CHECK (Sexe IN ('M','F')),
    DateNaissance DATE NOT NULL,
    Telephone VARCHAR(20),
    Adresse NVARCHAR(150),
    DateInscription DATE DEFAULT GETDATE()
);

----

CREATE TABLE clinique.Consultations (
    ConsultationID INT IDENTITY(1,1) PRIMARY KEY,
    PatientID INT NOT NULL,
    MedecinID INT NOT NULL,
    DateHeure DATETIME2 NOT NULL,
    Motif NVARCHAR(200),
    Diagnostic NVARCHAR(200),
    Statut NVARCHAR(20)
    CHECK (Statut IN ('En attente','Terminee','Annulee')),

    FOREIGN KEY (PatientID)
    REFERENCES clinique.Patients(PatientID),

    FOREIGN KEY (MedecinID)
    REFERENCES clinique.Medecins(MedecinID)
);

----

CREATE TABLE clinique.Medicaments (
    MedicamentID INT IDENTITY(1,1) PRIMARY KEY,
    NomCommercial NVARCHAR(100) NOT NULL,
    DCI NVARCHAR(100),
    Categorie NVARCHAR(100),
    PrixUnitaire DECIMAL(10,2),
    Stock INT DEFAULT 0
);

----

CREATE TABLE clinique.Prescriptions (
    PrescriptionID INT IDENTITY(1,1) PRIMARY KEY,
    ConsultationID INT NOT NULL,
    MedicamentID INT NOT NULL,
    Posologie NVARCHAR(100),
    DureeJours INT,
    Quantite INT,

    FOREIGN KEY (ConsultationID)
    REFERENCES clinique.Consultations(ConsultationID),

    FOREIGN KEY (MedicamentID)
    REFERENCES clinique.Medicaments(MedicamentID)
);

----

CREATE TABLE clinique.Factures (
    FactureID INT IDENTITY(1,1) PRIMARY KEY,
    ConsultationID INT UNIQUE NOT NULL,
    DateFacture DATE DEFAULT GETDATE(),
    MontantBase DECIMAL(10,2) NOT NULL,
    Remise DECIMAL(5,2) DEFAULT 0,

    MontantNet AS (MontantBase - (MontantBase * Remise / 100)),

    StatutPaiement NVARCHAR(20)
    CHECK (StatutPaiement IN ('Payee','Non payee')),

    FOREIGN KEY (ConsultationID)
    REFERENCES clinique.Consultations(ConsultationID)
);


--- Section 3 : Cr�ation des index et des vues
--- INDEX

CREATE NONCLUSTERED INDEX idx_specialite
ON clinique.Medecins(SpecialiteID);

CREATE NONCLUSTERED INDEX idx_patient
ON clinique.Consultations(PatientID);

CREATE NONCLUSTERED INDEX idx_facture_statut
ON clinique.Factures(StatutPaiement);

--- VUES

-- D�tail consultations

CREATE VIEW clinique.Vue_Consultations_Detail AS
SELECT
    p.Nom + ' ' + p.Prenom AS Patient,
    m.Nom + ' ' + m.Prenom AS Medecin,
    s.Libelle AS Specialite,
    c.DateHeure,
    c.Motif,
    c.Statut
FROM clinique.Consultations c
INNER JOIN clinique.Patients p
ON c.PatientID = p.PatientID
INNER JOIN clinique.Medecins m
ON c.MedecinID = m.MedecinID
INNER JOIN clinique.Specialites s
ON m.SpecialiteID = s.SpecialiteID;

-- Factures impay�es

CREATE VIEW clinique.Vue_Factures_Impayees AS
SELECT
    p.Nom + ' ' + p.Prenom AS Patient,
    p.Telephone,
    f.MontantNet,
    f.DateFacture
FROM clinique.Factures f
INNER JOIN clinique.Consultations c
ON f.ConsultationID = c.ConsultationID
INNER JOIN clinique.Patients p
ON c.PatientID = p.PatientID
WHERE f.StatutPaiement = 'Non payee';

--- Section 4 : Modifications ALTER TABLE

ALTER TABLE clinique.Consultations
ADD NotesInternes NVARCHAR(MAX);

ALTER TABLE clinique.Medecins
ADD SpecialisationComplementaire NVARCHAR(100);

ALTER TABLE clinique.Patients
ADD DerniereMaj DATETIME2 DEFAULT GETDATE();

ALTER TABLE clinique.Patients
ALTER COLUMN Adresse NVARCHAR(300);

ALTER TABLE clinique.Patients
ADD CONSTRAINT CK_DateNaissance
CHECK (DateNaissance < GETDATE());

ALTER TABLE clinique.Patients
ADD GroupeSanguin VARCHAR(5);

ALTER TABLE clinique.Patients
DROP COLUMN GroupeSanguin;

---  Section 5 : Insertions de donn�es

-- Specialites

INSERT INTO clinique.Specialites (Libelle,TarifBase) VALUES
('Pediatrie',1500),
('Cardiologie',2500),
('Dermatologie',2000),
('Gynecologie',2200),
('Medecine Generale',1200),
('Ophtalmologie',1800);

SELECT * FROM clinique.Specialites;

-- Medecins

INSERT INTO clinique.Medecins
(Matricule,Nom,Prenom,Email,Telephone,DateEmbauche,Salaire,SpecialiteID)
VALUES
('MED-001','Jean','Robenson','robenson@clinique.ht','50937000001','2021-01-10',55000,1),
('MED-002','Pierre','Stanley','stanley@clinique.ht','50937000002','2020-02-15',60000,2),
('MED-003','Joseph','Claudel','claudel@clinique.ht','50937000003','2019-03-12',58000,3),
('MED-004','Louis','Gerald','gerald@clinique.ht','50937000004','2022-04-18',54000,4),
('MED-005','Charles','David','david@clinique.ht','50937000005','2021-05-20',52000,5),
('MED-006','Michel','Rony','rony@clinique.ht','50937000006','2023-06-25',50000,6),
('MED-007', 'Joseph','Romy','romy@clinique.ht','5093700007','2018-03-20',90000,3),
('MED-008','Jean','Benson','benson@clinique.ht','5093700008','2020-02-18',45000,4);

SELECT * FROM clinique.Medecins

-- Patients

INSERT INTO clinique.Patients
(NumeroDossier,Nom,Prenom,Sexe,DateNaissance,Telephone,Adresse)
VALUES
('PAT-2024-001','Jean','Patrick','M','1998-02-10','50936000001','Les Cayes'),
('PAT-2024-002','Louis','Sandra','F','1995-06-12','50936000002','Camp Perrin'),
('PAT-2024-003','Pierre','Mikael','M','2000-01-15','50936000003','Aquin'),
('PAT-2024-004','Joseph','Clara','F','1993-09-10','50936000004','Torbeck'),
('PAT-2024-005','Charles','David','M','1997-05-05','50936000005','Port Salut'),
('PAT-2024-006','Michel','Ruth','F','1994-07-18','50936000006','Chantal'),
('PAT-2024-007','Andre','Kevin','M','1999-03-21','50936000007','Maniche'),
('PAT-2024-008','Etienne','Sophia','F','1996-12-11','50936000008','Les Cayes'),
('PAT-2024-009','Gerald','Samuel','M','2001-08-02','50936000009','Aquin'),
('PAT-2024-010','Pierre','Naika','F','1992-04-09','50936000010','Camp Perrin'),
('PAT-2024-011','Louis','Ruth','F','1997-10-25','50936000011','Port Salut'),
('PAT-2024-012','Joseph','Daniel','M','1993-11-19','50936000012','Torbeck'),
('PAT-2024-013','Charles','Mika','M','2000-06-30','50936000013','Maniche'),
('PAT-2024-014','Michel','Sarah','F','1995-02-14','50936000014','Les Cayes'),
('PAT-2024-015','Andre','Stanley','M','1999-01-07','50936000015','Chantal');

SELECT * FROM clinique.Patients

-- Medicaments

INSERT INTO clinique.Medicaments
(NomCommercial,DCI,Categorie,PrixUnitaire,Stock)
VALUES
('Paracetamol','Acetaminophen','Analgesique',50,200),
('Amoxicilline','Amoxicillin','Antibiotique',120,150),
('Ibuprofen','Ibuprofen','Anti inflammatoire',80,180),
('Artemether','Artemether','Antipaludeen',200,90),
('Coartem','Artemether Lumefantrine','Antipaludeen',250,70),
('Doliprane','Paracetamol','Analgesique',60,160),
('Azithromycine','Azithromycin','Antibiotique',220,50),
('Ciprofloxacine','Ciprofloxacin','Antibiotique',180,65),
('Metronidazole','Metronidazole','Antibiotique',100,120),
('Vitamine C','Acide Ascorbique','Supplement',40,300);

SELECT * FROM clinique.Medicaments

-- Consultations

INSERT INTO clinique.Consultations
(PatientID,MedecinID,DateHeure,Motif,Diagnostic,Statut)
VALUES
(1,1,'2024-01-10','Fievre','Paludisme','Terminee'),
(2,2,'2024-01-11','Douleur poitrine','Hypertension','Terminee'),
(3,3,'2024-01-12','Allergie peau','Dermatite','Terminee'),
(4,4,'2024-01-13','Controle grossesse','Suivi normal','Terminee'),
(5,5,'2024-01-14','Mal de tete','Migraine','Terminee'),
(6,6,'2024-01-15','Vision floue','Probleme vue','Terminee'),
(7,7,'2024-02-10','Fievre','Infection','Terminee'),
(8,8,'2024-02-11','Douleur poitrine','Controle','Terminee'),
(9,1,'2024-02-12','Boutons peau','Acne','Terminee'),
(10,2,'2024-02-13','Controle grossesse','Suivi','Terminee'),
(11,3,'2024-02-14','Fatigue','Anemie','En attente'),
(12,4,'2024-02-15','Vision floue','Myopie','Terminee'),
(13,5,'2024-03-10','Fievre','Grippe','Terminee'),
(14,6,'2024-03-11','Douleur coeur','Controle','Annulee'),
(15,7,'2024-03-12','Rougeur peau','Allergie','Terminee'),
(1,8,'2024-03-13','Consultation','Controle','Terminee'),
(2,1,'2024-03-14','Mal ventre','Gastrite','Terminee'),
(3,2,'2024-03-15','Vision trouble','Fatigue oculaire','Terminee'),
(4,3,'2024-03-16','Fievre','Infection','En attente'),
(5,4,'2024-03-17','Controle coeur','Controle','Terminee');

SELECT * FROM clinique.Consultations

-- Prescriptions

INSERT INTO clinique.Prescriptions
(ConsultationID,MedicamentID,Posologie,DureeJours,Quantite)
VALUES
(1,4,'2 fois par jour',5,10),
(2,2,'3 fois par jour',7,21),
(3,7,'1 fois par jour',5,5),
(4,9,'1 fois par jour',10,10),
(5,1,'2 fois par jour',3,6),
(6,10,'2 fois par jour',5,10),
(7,4,'2 fois par jour',5,10),
(8,2,'3 fois par jour',7,21),
(9,9,'2 fois par jour',5,10),
(10,9,'1 fois par jour',10,10),
(12,3,'2 fois par jour',7,14),
(13,1,'2 fois par jour',3,6),
(15,7,'1 fois par jour',5,5),
(16,9,'1 fois par jour',10,10),
(17,8,'2 fois par jour',7,14);

SELECT * FROM clinique.Prescriptions

-- Factures

INSERT INTO clinique.Factures
(ConsultationID,MontantBase,Remise,StatutPaiement)
VALUES
(1,1500,0,'Payee'),
(2,2500,10,'Payee'),
(3,2000,0,'Payee'),
(4,2200,5,'Payee'),
(5,1200,0,'Payee'),
(6,1800,0,'Non payee'),
(7,1500,0,'Payee'),
(8,2500,0,'Non payee'),
(9,2000,5,'Payee'),
(10,2200,0,'Payee'),
(12,1800,0,'Non payee'),
(13,1500,0,'Payee');

SELECT * FROM clinique.Factures 

-- Section 6 : Requ�tes SELECT

-- Requ�te 4.1

SELECT
m.Matricule,
m.Nom + ' ' + m.Prenom AS NomComplet,
m.Email,
s.Libelle
FROM clinique.Medecins m
INNER JOIN clinique.Specialites s
ON m.SpecialiteID = s.SpecialiteID
ORDER BY s.Libelle, m.Nom;

-- Requ�te 4.2

SELECT
NumeroDossier,
Nom + ' ' + Prenom AS NomComplet,
DateNaissance,
DATEDIFF(YEAR,DateNaissance,GETDATE()) AS Age
FROM clinique.Patients
WHERE DateNaissance > '1990-01-01'
ORDER BY Age;

-- Requ�te 4.3

SELECT
ConsultationID,
Motif,
Statut,
FORMAT(DateHeure,'dd/MM/yyyy') AS DateConsultation
FROM clinique.Consultations
WHERE Statut='Terminee'
ORDER BY DateHeure DESC;

-- Requ�te 4.4

SELECT TOP 5 WITH TIES
NomCommercial,
Categorie,
PrixUnitaire
FROM clinique.Medicaments
ORDER BY PrixUnitaire DESC;

--- Agr�gations et GROUP BY

-- Requ�te 4.5

SELECT 
    m.Nom + ' ' + m.Prenom AS NomMedecin,
    s.Libelle AS Specialite,
    COUNT(c.ConsultationID) AS TotalConsultations,
    COUNT(CASE WHEN c.Statut = 'Terminee' THEN 1 END) AS ConsultationsTerminees
FROM clinique.Medecins m
JOIN clinique.Specialites s 
    ON m.SpecialiteID = s.SpecialiteID
LEFT JOIN clinique.Consultations c 
    ON m.MedecinID = c.MedecinID
GROUP BY 
    m.Nom, m.Prenom, s.Libelle
ORDER BY 
    TotalConsultations DESC;

-- Requ�te 4.6

SELECT 
    s.Libelle AS Specialite,
    COUNT(f.FactureID) AS NombreFacturesPayees,
    ROUND(SUM(f.MontantNet),2) AS ChiffreAffaires
FROM clinique.Specialites s
JOIN clinique.Medecins m 
    ON s.SpecialiteID = m.SpecialiteID
JOIN clinique.Consultations c 
    ON m.MedecinID = c.MedecinID
JOIN clinique.Factures f 
    ON c.ConsultationID = f.ConsultationID
WHERE f.StatutPaiement = 'Payee'
GROUP BY 
    s.Libelle
HAVING 
    SUM(f.MontantNet) > 2000;

-- Requ�te 4.7

SELECT 
    Sexe,
    COUNT(*) AS NombrePatients,
    ROUND(AVG(DATEDIFF(YEAR, DateNaissance, GETDATE())),1) AS AgeMoyen,
    MAX(DateNaissance) AS PatientPlusJeune,
    MIN(DateNaissance) AS PatientPlusAge
FROM clinique.Patients
GROUP BY Sexe;


-- Requ�te 4.8

SELECT 
    NomCommercial,
    Categorie,
    Stock,
    CASE
        WHEN Stock < 20 THEN 'CRITIQUE'
        ELSE 'FAIBLE'
    END AS NiveauAlerte
FROM clinique.Medicaments
WHERE Stock <= 50;

-- Requ�te 4.9

SELECT 
    FORMAT(DateHeure,'yyyy-MM') AS Mois,
    COUNT(*) AS TotalConsultations,
    SUM(CASE WHEN Statut='Terminee' THEN 1 ELSE 0 END) AS ConsultationsTerminees,
    ROUND(
        (SUM(CASE WHEN Statut='Terminee' THEN 1 ELSE 0 END) * 100.0) / COUNT(*)
    ,1) AS TauxRealisation
FROM clinique.Consultations
WHERE YEAR(DateHeure) = 2024
GROUP BY FORMAT(DateHeure,'yyyy-MM');

--- Jointures

-- Requ�te 5.1

SELECT 
    c.DateHeure,
    p.Nom + ' ' + p.Prenom AS Patient,
    m.Nom + ' ' + m.Prenom AS Medecin,
    med.NomCommercial,
    pr.Posologie,
    pr.DureeJours,
    pr.Quantite
FROM clinique.Prescriptions pr
JOIN clinique.Consultations c 
    ON pr.ConsultationID = c.ConsultationID
JOIN clinique.Patients p 
    ON c.PatientID = p.PatientID
JOIN clinique.Medecins m 
    ON c.MedecinID = m.MedecinID
JOIN clinique.Medicaments med 
    ON pr.MedicamentID = med.MedicamentID
ORDER BY 
    c.DateHeure DESC;

-- Requ�te 5.2

SELECT 
    f.FactureID,
    f.DateFacture,
    p.Nom + ' ' + p.Prenom AS Patient,
    m.Nom + ' ' + m.Prenom AS Medecin,
    f.MontantBase,
    f.Remise,
    f.MontantNet
FROM clinique.Factures f
JOIN clinique.Consultations c 
    ON f.ConsultationID = c.ConsultationID
JOIN clinique.Patients p 
    ON c.PatientID = p.PatientID
JOIN clinique.Medecins m 
    ON c.MedecinID = m.MedecinID
WHERE f.StatutPaiement = 'Payee';

-- Requ�te 5.3

SELECT 
    p.NumeroDossier,
    p.Nom + ' ' + p.Prenom AS Patient,
    p.DateInscription
FROM clinique.Patients p
LEFT JOIN clinique.Consultations c 
    ON p.PatientID = c.PatientID
WHERE c.ConsultationID IS NULL;

-- Requ�te 5.4

SELECT 
    m.Nom + ' ' + m.Prenom AS Medecin,
    s.Libelle AS Specialite,
    ISNULL(SUM(f.MontantNet),0) AS RevenusTotaux
FROM clinique.Medecins m
JOIN clinique.Specialites s 
    ON m.SpecialiteID = s.SpecialiteID
LEFT JOIN clinique.Consultations c 
    ON m.MedecinID = c.MedecinID
LEFT JOIN clinique.Factures f 
    ON c.ConsultationID = f.ConsultationID
    AND f.StatutPaiement='Payee'
GROUP BY 
    m.Nom, m.Prenom, s.Libelle;

-- Requ�te 5.5

SELECT 
    COALESCE(s.Libelle,'Sp�cialit� non renseign�e') AS Specialite,
    COALESCE(m.Nom + ' ' + m.Prenom,'Aucun m�decin') AS Medecin
FROM clinique.Specialites s
FULL OUTER JOIN clinique.Medecins m
    ON s.SpecialiteID = m.SpecialiteID;

-- Requ�te 5.6

SELECT 
    p.Nom + ' ' + p.Prenom AS Patient,
    COUNT(DISTINCT c.MedecinID) AS NombreMedecins
FROM clinique.Patients p
JOIN clinique.Consultations c 
    ON p.PatientID = c.PatientID
GROUP BY 
    p.Nom, p.Prenom
HAVING 
    COUNT(DISTINCT c.MedecinID) >= 2;

-- Requ�te 5.7

SELECT 
    p.Nom + ' ' + p.Prenom AS Patient,
    dc.DateHeure,
    dc.Motif,
    dc.Medecin
FROM clinique.Patients p
OUTER APPLY (
    SELECT TOP 1
        c.DateHeure,
        c.Motif,
        m.Nom + ' ' + m.Prenom AS Medecin
    FROM clinique.Consultations c
    JOIN clinique.Medecins m 
        ON c.MedecinID = m.MedecinID
    WHERE c.PatientID = p.PatientID
    ORDER BY c.DateHeure DESC
) dc;

-- Requ�te 5.8

SELECT 
    c.DateHeure,
    p.Nom + ' ' + p.Prenom AS Patient,
    pr.Medicament,
    pr.Posologie
FROM clinique.Consultations c
JOIN clinique.Patients p 
    ON c.PatientID = p.PatientID
CROSS APPLY (
    SELECT 
        med.NomCommercial AS Medicament,
        pr.Posologie
    FROM clinique.Prescriptions pr
    JOIN clinique.Medicaments med 
        ON pr.MedicamentID = med.MedicamentID
    WHERE pr.ConsultationID = c.ConsultationID
) pr
WHERE c.Statut='Terminee';